;(function ($) {

    var init = function () {
        codeMap(); //验证码
        findPwdForm(); //密码找回
    };
    var setCode = function () {
        var code = $(".code-box").Verification.getCode();
        $("#verification-code").val(code.toLowerCase());
    };
    var codeMap = function () {
        $(".code-box").Verification();
        setCode();
    };

    var findPwdForm = function () {

        $(".code-box").on("click", function () {
            setCode();
        });

        $("#findPwdForm").validate({
            rules: {
                "reg-email": {
                    required: true,
                    email: true
                },
                "verification-code": { },
                "reg-code": {
                    required: true,
                    equalTo: "#verification-code"
                }
            },
            messages: {
                "reg-email": {
                    required: "请输入注册邮箱",
                    email: "邮箱格式错误"
                },
                "verification-code": { },
                "reg-code": {
                    required: "请输入验证码",
                    equalTo: "验证码错误"
                }
            },
            errorPlacement: function (error, element) {// 提示信息显示的位置
                error.appendTo(element.siblings(".errorMessage"));
                element.siblings(".errorMessage").fadeIn(300);
            }
        });
        $("#resetPwdForm").validate({
            rules: {
                "ret-pwd": {
                    required: true,
                    minlength: 5
                },
                "rep-pwd": {
                    required: true,
                    equalTo: "#ret-pwd"
                }
            },
            messages: {
                "ret-pwd": {
                    required: "请输入新密码",
                    minlength: "密码不低于五个字符"
                },
                "rep-pwd": {
                    required: "请输入重复新密码",
                    equalTo: "2次输入的密码不一致"
                }
            },
            errorPlacement: function (error, element) {// 提示信息显示的位置
                error.appendTo(element.siblings(".errorMessage"));
                element.siblings(".errorMessage").fadeIn(300);
            }
        });
    };
    init();
})(jQuery);
