;
(function ($) {
    var init = function () {
        header_bg(); //hrforce header
        hrforce_banner(); //hrforce banner
        win_resize(); //window resize
        doc_scroll(); //document scroll
        chunck_height(); //chunck height
    };
    var hrforce_form = function () {
        //自定义验证
        jQuery.validator.addMethod("isMobile", function (value, element) {
            var length = value.length;
            return this.optional(element) || (length == 11 && /^1[3|4|5|7|8][0-9]\d{4,8}$/.test(value));
        }, "手机号格式不正确");
        //表单验证
        $("#index-form").validate({
            rules: {
                "hrforce-username": {
                    required: true,
                    maxlength: 20
                },
                "hrforce-phone": {
                    required: true,
                    minlength: 11,
                    isMobile: true
                },
                "hrforce-message": {
                    required: true,
                    maxlength: 200
                }
            },
            messages: {
                "hrforce-username": {
                    required: "请输入姓名",
                    maxlength: "用户名最多20个字符"
                },
                "hrforce-phone": {
                    required: "请输入手机号",
                    minlength: "手机号不能少于11位数字",
                    isMobile: "手机号格式不正确"
                },
                "hrforce-message": {
                    required: "留言信息不能为空",
                    maxlength: "留言信息最多200个字符"
                }
            },
            errorPlacement: function (error, element) {// 提示信息显示的位置
                error.appendTo(element.siblings(".message-box"));
                element.siblings(".message-box").stop().animate({
                    "opacity": 1,
                    "top": "-23px"
                }, 600);
            },
            success: function (label) {
                label.parent(".message-box").stop().animate({
                    "opacity": 0,
                    "top": "23px"
                }, 600);
            }
        });
    };
    var header_bg = function () {
        if ($(window).scrollTop() > 50) {
            $(".hrforce-header").addClass("hrforce-grenn-header");
        } else {
            $(".hrforce-header").removeClass("hrforce-grenn-header");
        }
    };
    var hrforce_banner = function () {
        $(".hrforce-banner").mySlide({
            actCallback: function (index, plug) {
                if (index == 0) {
                    //第二页结束动画
                    $(".ani1-01").transition({x: '-40px', opacity: 0, delay: 300}, 600, "ease");
                    $(".ani1-02").transition({x: '-40px', opacity: 0, delay: 300}, 600, "ease");
                    $(".ani1-03").transition({x: '-40px', opacity: 0, delay: 300}, 600, "ease");
                    $(".ani1-04").transition({x: '140px', opacity: 0, delay: 300}, 600, "ease", function () {
                        plug.fadeInHandle(index);
                        //第一页开始动画 $(".ani-01")
                        $(".ani-01").transition({transform: 'translateY(-40px)', opacity: 1, delay: 500}, 600, "ease");
                        $(".ani-02").transition({transform: 'scale(1)', opacity: 1, delay: 1000}, 600, "ease");
                        $(".ani-03").transition({transform: 'translateY(40px)', opacity: 1, delay: 1500}, 600, "ease");
                        $(".ani-04").transition({transform: 'translateY(40px)', opacity: 1, delay: 1500}, 600, "ease");
                        $(".ani-05").transition({
                            transform: 'scale(1) rotate(360deg)',
                            opacity: 1,
                            delay: 1800
                        }, 600, "ease", function () {
                            plug.bindClick();
                        });
                    });
                }
                if (index == 1) {
                    //第一页结束动画
                    $(".ani-01").transition({transform: "scale(0.5) translateY(0)", opacity: 0, delay: 300}, 500, "ease");
                    $(".ani-02").transition({transform: 'scale(0.5)', opacity: 0, delay: 300}, 500, "ease");
                    $(".ani-03").transition({transform: "scale(0.5) translateY(0)", opacity: 0, delay: 300}, 500, "ease");
                    $(".ani-04").transition({transform: "scale(0.5) translateY(0)", opacity: 0, delay: 300}, 500, "ease");
                    $(".ani-05").transition({
                        transform: 'scale(0.2) rotate(-360deg)',
                        opacity: 0,
                        delay: 700
                    }, 500, "ease", function () {
                        plug.fadeInHandle(index);
                        //第二页开始动画
                        $(".ani1-01").transition({x: '40px', opacity: 1, delay: 1000}, 500, "ease");
                        $(".ani1-02").transition({x: '40px', opacity: 1, delay: 1000}, 500, "ease");
                        $(".ani1-03").transition({x: '40px', opacity: 1, delay: 1000}, 500, "ease");
                        $(".ani1-04").transition({x: '-100px', opacity: 1, delay: 1500}, 500, "ease", function () {
                            plug.bindClick();
                        });
                    });
                }
            }
        });
        $(".hf-bg01,.hf-bg02").parallax("50%", -0.3, "bg");
        $(".chunck01-bg").parallax("100%", -0.1, "bg");
        $(".chunck02-ani01").parallax("100%", 0.15, "fg");
        $(".chunck02-ani03").parallax("100%", -0.15, "fg");
    };
    var win_resize = function () {
        $(window).resize(function () {
            swiper_height();
            chunck_height();
        });
    };
    var doc_scroll = function () {
        $(document).scroll(function () {
            header_bg();
        });
    };
    var chunck_height = function () {
        var win_height = $(window).height();
        var hd_height = $(".hrforce-header").height();
        var tit1_height = $(".hrforce-chunck01-tit").height();
        $(".hrforce-chunck01-con,.hrforce-chunck03-con").height(win_height - hd_height - tit1_height);
    };
    var chunck03_l_swiper = function () {
        $(".chunck03-l-box").mySwiper({
            prevClass: ".chunck03-l-preBtn",
            pagingClass: ".chunck03-l-pagingBtn"
        });
    };
    var chunck03_r_swiper = function () {
        $(".chunck03-r-box").mySwiper({
            prevClass: ".chunck03-r-preBtn",
            nextClass: ".chunck03-r-nextBtn",
            pagingClass: ".chunck03-r-pagingBtn",
            slideType: "fade"
        });
    };
    var hrforce_map = function () {
        var len = $(".hrforce-info-box").children(".hrforce-info").length;
        var h = $(".hrforce-info-box").height();
        var t = h / len;

        // 百度地图API功能
        hrforce_map_active(121.4258514582, 31.2616755463, "我在 品尊国际公寓 附近 >");

        $(".hrforce-info").on("click", function () {
            var index = $(this).index();
            $(".hrforce-info-line").animate({
                top: t * index
            }, 300);
            if (index == 0) {
                hrforce_map_active(121.4258514582, 31.2616755463, "我在 品尊国际公寓 附近 >");
            }
            if (index == 1) {
                hrforce_map_active(114.1815262160, 22.3198556556, "我在 旺角广场 附近 >");
            }
        });


    };
    var hrforce_map_active = function (longitude, dimensionality, describe) {
        var map = new BMap.Map("hrfoece-map");
        var point = new BMap.Point(longitude, dimensionality);
        map.centerAndZoom(point, 16);

        // 复杂的自定义覆盖物
        function ComplexCustomOverlay(point, text, mouseoverText) {
            this._point = point;
            this._text = text;
            this._overText = mouseoverText;
        }

        ComplexCustomOverlay.prototype = new BMap.Overlay();
        ComplexCustomOverlay.prototype.initialize = function (map) {
            this._map = map;
            var div = this._div = document.createElement("div");
            $(div).addClass("mapTooltip");
            var span = this._span = document.createElement("span");
            div.appendChild(span);
            span.appendChild(document.createTextNode(this._text));
            var that = this;

            var arrow = this._arrow = document.createElement("div");
            arrow.style.left = "50%";
            div.appendChild(arrow);

            map.getPanes().labelPane.appendChild(div);
            return div;
        }
        ComplexCustomOverlay.prototype.draw = function () {
            var map = this._map;
            var pixel = map.pointToOverlayPixel(this._point);
            this._div.style.left = pixel.x - parseInt(this._arrow.style.left) - 100 + "px";
            this._div.style.top = pixel.y - 30 + "px";
        }

        var myCompOverlay = new ComplexCustomOverlay(new BMap.Point(longitude, dimensionality), describe);

        map.addOverlay(myCompOverlay);
    }
    var swiper_height = function () {
        var winHeight = $(window).height();
        $(".hrforce-banner,.hrforce-banner ul,.hrforce-banner ul li,.hf-mask").height(winHeight);
    };
    var loddingHandle = function () {
        var imagesArray = [
            "../images/ani-box05.png",
            "../images/banner-02-img01.png",
            "../images/banner-02-img02.png",
            "../images/banner-nextBtn-active.png",
            "../images/banner-nextBtn.png",
            "../images/banner-pagingBtn-active.png",
            "../images/banner-pagingBtn.png",
            "../images/banner-preBtn-active.png",
            "../images/banner-preBtn.png",
            "../images/chunck01-ani01.png",
            "../images/chunck02-ani03.png",
            "../images/chunck03-l-lastBtn.png",
            "../images/chunck03-r-lastBtn-active.png",
            "../images/chunck03-r-nextBtn-active.png",
            "../images/chunck03-r-nextBtn.png",
            "../images/chunck03-r-pagingBtn.png",
            "../images/chunk01-img.jpg",
            "../images/coop-active-ico.png",
            "../images/coop-ico.png",
            "../images/eu-active-ico.png",
            "../images/eu-ico.png",
            "../images/hrforce-banner-01.jpg",
            "../images/hrforce-banner-02.jpg",
            "../images/hrforce-glare.png",
            "../images/hrforce-green-log.png",
            "../images/hrforce-log.png",
            "../images/hrforce-mobile.png",
            "../images/hrforce-video-bg.png",
            "../images/hrforce-video-bottom.png",
            "../images/hrforce-video-fg.png",
            "../images/pu-active-ico.png",
            "../images/pu-ico.png",
            "../images/shop-log01.png",
            "../images/shop-log02.png",
            "../images/shop-white-log02.png",
            "../images/zyc-code.jpg",
            "../images/zyc-grenn-log.png",
            "../images/zyc-log.png",
        ];
        var imgNum = 0;
        $.imgpreload(imagesArray, {
            each: function () {
                var status = $(this).data('loaded') ? 'success' : 'error';
                if (status == "success") {
                    var v = (parseFloat(++imgNum) / imagesArray.length).toFixed(2);
                    $(".loadding-txt-fg").animate({
                        "width": Math.round(v * 100) + "%"
                    },10,function () {
                        if(Math.round(v * 100) == 100){
                            $(".loadding-container").fadeOut(500,function () {
                                chunck03_l_swiper(); //chunck03 left swiper
                                chunck03_r_swiper(); //chunck03 right swiper
                                hrforce_map(); //hrforce map
                                hrforce_form(); //hrforce form
                            });
                        }
                    });
                }
            },
            all: function () {
            }
        });
    }
    loddingHandle();
    init();
})(jQuery);