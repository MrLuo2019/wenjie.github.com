;
(function($) {
	var init = function() {
		input_style(); //input value
		checkbox(); //checkbox
		login_submit(); //login submit
	};
	var showLoginMessage = function(obj) {
		var val = obj.attr("defVal");
		$(".login-message").html(val);
		$(".login-message").stop().animate({
			opacity: 1
		}, 500);
		obj.addClass("error");
		obj.focus();
	};
	var hideMessageBox = function(obj) {
		$(".login-message").stop().animate({
			opacity: 0
		}, 500);
		if(obj.hasClass("error")) {
			obj.removeClass("error");
		}
	};
	var login_submit = function() {
        $("#loginForm").validate({
			rules: {
				"userName": {
                    required: true
				},
                "userPassword": {
                    required: true
                }
            },
			messages: {
                "userName": {
                    required: "请输入用户名"
                },
                "userPassword": {
                    required: "请输入密码"
                }
			},
            errorPlacement: function (error, element) {// 提示信息显示的位置
                element.parents(".loginForm").siblings(".errorMessage").html(error);
                element.parents(".loginForm").siblings(".errorMessage").stop().animate({
					"opacity": "1"
				},300);
            },
		});
		// $("#loginForm").submit(function(event) {
		// 	var event = window.event || event;
		// 	var user_name = $("#userName");
		// 	var user_password = $("#userPassword");
        //
		// 	if(user_name.val() == "" || user_password.val() == "") {
		// 		event.preventDefault(); // 兼容标准浏览器
		// 		window.event.returnValue = false; // 兼容IE6~8
		// 	}
		// 	if(user_name.val() == "") {
		// 		showLoginMessage(user_name);
		// 	} else if(user_password.val() == "") {
		// 		showLoginMessage(user_password);
		// 	}
		// });
		// $(".login-input").keyup(function() {
		// 	if($(this).val() != ""){
         //        hideMessageBox($(this));
		// 	}
		// });
	};
	var checkbox = function() {
		$("#login-chekebox").on("click", function() {
			$(this).toggleClass("active");
		});
	};
	var input_style = function() {
		var isPlaceholder = 'placeholder' in document.createElement('input');
		if(!isPlaceholder) {
			$.each($(".login-input"), function(i, e) {
				var defVal = $(this).attr("defVal");
				var defType = $(this).attr("type");
				var defColor = "#bdbdbd";
				var type = $(this).attr("type");
				$(this).val(defVal).attr("type", "text").css("color", defColor);
				$(this).focus(function() {
					if($(this).val() == defVal) {
						$(this).val("").attr("type", defType).css("color", "#232323");
					}
				}).blur(function() {
					if($(this).val() == "") {
						$(this).val(defVal).attr("type", "text").css("color", defColor);
					}
				});
			});
		}
	};

	init();
})(jQuery);