;(function ($) {

    var init = function () {
        $(".goPrePage").on("click", function () {

        });
    };

    init();

})(jQuery);