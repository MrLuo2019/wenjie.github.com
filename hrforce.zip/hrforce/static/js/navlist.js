;(function ($) {

    var init = function () {
        $(".header-nav-list ul li div.proService").on("click", function () {
            $(this).siblings("#dropDownList").stop().slideToggle();
            $(this).find("span.triangle").toggleClass("active");
        });
    };

    init();

})(jQuery);