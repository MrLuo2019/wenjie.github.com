;
(function ($) {
    var init = function () {
        checkbox(); //checkbox
        upDownBtn(); //upDownBtn
        registerForm(); //表单
    };
    var checkbox = function () {
        $("#reg-chekebox").on("click", function () {
            $(this).toggleClass("active");
        });
    };

    var upDownBtn = function () {
        $(".code-btn a.packDown").on("click", function () {
            $(this).parents(".code-btn").hide();
            $(".code-input").show();
        });
        $(".code-input p a.packUp").on("click", function () {
            $(".code-input").hide();
            $(".code-btn").show();
        });
    };

    var registerForm = function () {
        //自定义验证
        jQuery.validator.addMethod("isMobile", function (value, element) {
            var length = value.length;
            return this.optional(element) || (length == 11 && /^1[3|4|5|7|8][0-9]\d{4,8}$/.test(value));
        }, "手机号格式不正确");
        jQuery.validator.addMethod("isAccount", function (value, element) {
            var length = value.length;
            return this.optional(element) || /^[a-zA-Z][a-zA-Z0-9]{5,24}$/.test(value);
        }, "登录账号格式不正确");
        $("#regForm").validate({
            rules: {
                "regEmail": {
                    required: true,
                    email: true
                },
                "regTradeName": {
                    required: true
                },
                "regAccount": {
                    required: true,
                    isAccount:true
                },
                "regName": {
                    required: true
                },
                "regPhone": {
                    required: true,
                    isMobile: true
                },
                "regPhoneCode": {
                    required: true
                }
            },
            messages: {
                "regEmail": {
                    required: "请输入邮箱地址",
                    email: "邮箱格式不正确"
                },
                "regTradeName": {
                    required: "请输入企业名称"
                },
                "regAccount": {
                    required: "请输入登录账户",
                    isAccount: "登录账号格式不正确"
                },
                "regName": {
                    required: "请输入联系人"
                },
                "regPhone": {
                    required: "请输入联系人手机号",
                    isMobile: "请输入正确的手机号"
                },
                "regPhoneCode": {
                    required: "请输入手机验证码"
                }
            },
            errorPlacement: function (error, element) {// 提示信息显示的位置
                element.siblings(".errorMessage").html(error);
                element.siblings(".errorMessage").fadeIn(300);
            },
            submitHandler:function(form){
                alert("提交事件!");
                form.submit();
            }
        });
    }

    init();
})(jQuery);